var myobject=function(id,name){
	this.id=id;
	this.name=name;
};

myobject.prototype={
	id:0,
	name:null,
	show:function(){
		console.log(this.name);
	},
	hide:function(){}
};


var obj=new myobject(5,"namme");
obj.show();
/*
//thuoc tinh
myobject.prototype={
	id:0,
	name:null
};

myobject.prototype.show=function(abc){
	console.log(this.id+":"+this.name+":"+abc);
};
*/